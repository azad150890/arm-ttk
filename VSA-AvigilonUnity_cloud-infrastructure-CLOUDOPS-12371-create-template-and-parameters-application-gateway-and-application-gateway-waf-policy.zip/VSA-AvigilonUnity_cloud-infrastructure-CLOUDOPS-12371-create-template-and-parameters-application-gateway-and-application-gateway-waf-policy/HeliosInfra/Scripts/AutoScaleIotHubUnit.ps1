[CmdletBinding()]
Param (
    [string] $Subscription,
    [string] $EnvironmentToken
)

#Set-StrictMode -Version Latest
#########################################
$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Connect-AzAccount `
        -ServicePrincipal `
        -Tenant $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
#########################################################

# Gets the Quota Metrics for an IotHub.
$IotHubUnitMetrics = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

# 80% of Daily Message quota
$DailyMessageQuota = [int]$IotHubUnitMetrics.MaxValue[0] * 0.80

# Scale Out Logic compares if total messages used today is greater than 80% of Daily Message quota and increases the hub units by 1, if true.
$IotHubdetails = Get-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub"
$PresentIotHubUnit = $IotHubdetails.sku.Capacity
If([int]$IotHubUnitMetrics.CurrentValue[0] -ge [int]$DailyMessageQuota -and $PresentIotHubUnit -ne '9'){
    $IncreaseIotHubUnit = $PresentIotHubUnit + 1
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units $IncreaseIotHubUnit -SkuName $IotHubdetails.sku.Name
    Write-output "Increased IotHubUnits by 1 unit and Current number of IotHubUnits is $IncreaseIotHubUnit"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}

If($PresentIotHubUnit -eq '9' -and $IotHubdetails.sku.Name -eq 'S1'){
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units 1 -SkuName 'S2'
    Write-Output "Switched SKU tier from S1 to S2"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}

If($PresentIotHubUnit -eq '9' -and $IotHubdetails.sku.Name -eq 'S2'){
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units 1 -SkuName 'S3'
    Write-Output "Switched SKU tier from S2 to S3"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}

# Scale In Logic compares if percentage of time is greater than or equal to 80% of day and message quota used is less than 50% per day 
$now = (Get-Date).ToUniversalTime()
$startofday = $now.Date
# Percentage of time used per day
$pctOfTimeUsed = ($now - $startofday).TotalDays * 100
# Percentage of quota used per day
$pctOfQuotaUsed = [int]$IotHubUnitMetrics.CurrentValue[0] / [int]$IotHubUnitMetrics.MaxValue[0] * 100

If($pctOfTimeUsed -ge '80' -and $pctOfQuotaUsed -lt '40' -and $PresentIotHubUnit -gt '1') {
    $DecreaseIotHubUnit = $PresentIotHubUnit - 1
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units $DecreaseIotHubUnit -SkuName $IotHubdetails.sku.Name
    Write-output "Decresed IotHubUnits by 1 unit and Current number of IotHubUnits is $DecreaseIotHubUnit"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}

If($pctOfTimeUsed -ge '80' -and $pctOfQuotaUsed -lt '40' -and $PresentIotHubUnit -eq '1' -and $IotHubdetails.sku.Name -eq 'S2' ) {
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units 9 -SkuName 'S1'
    Write-output "Switched SKU tier from S2 to S1"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}

If($pctOfTimeUsed -ge '80' -and $pctOfQuotaUsed -lt '40' -and $PresentIotHubUnit -eq '1' -and $IotHubdetails.sku.Name -eq 'S3' ) {
    Set-AzIotHub -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-iot-hub" -Units 9 -SkuName 'S2'
    Write-output "Switched SKU tier from S3 to S2"
    # Setup Alert for 85% Daily Message Quota
    $IotHubUnitMetrics_Alert = Get-AzIotHubQuotaMetric -Name "blue-$EnvironmentToken-iot-hub" -ResourceGroupName "blue-$environmentToken-rg"

    # 85% of Daily Message quota
    $Threshold = [int]$IotHubUnitMetrics_Alert.MaxValue[0] * 0.85
    $Signal_name = "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg"
    $Description = "The IOT Hub dailyMessageQuotaUsed in blue-$EnvironmentToken-rg is over 85% of the scaled quota, Consider scaling out."

    # Action group
    $ActionGroup = Get-AzActionGroup -ResourceGroupName "blue-$EnvironmentToken-rg" -Name "blue-$EnvironmentToken-alert"
    $actionGroupId = New-AzActionGroup -ActionGroupId $actionGroup.Id

    # Adding Alert
    $criteria = New-AzMetricAlertRuleV2Criteria -MetricName "dailyMessageQuotaUsed" -Operator "GreaterThan" -TimeAggregation "Maximum" -Threshold $Threshold
    $serviceResource = Get-AzResource -ResourceGroupName "blue-$EnvironmentToken-rg" -ResourceName "blue-$EnvironmentToken-iot-hub" -ResourceType "microsoft.devices/iothubs"

    Add-AzMetricAlertRuleV2 -Name "IOT Total Message Count Over Threshold for blue-$EnvironmentToken-rg" -ResourceGroupName "blue-$EnvironmentToken-rg" -TargetResourceId $serviceResource.ResourceId -Description $Description `
            -WindowSize '0:5' -Frequency '0:5' -Severity '2' -ActionGroup $actionGroupId -Condition $criteria 
    Write-Output "Alert has been setup"
}