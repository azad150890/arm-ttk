# Avigilon Unity Cloud Infrastructure

## Components

### Helios

See [docs](HeliosInfra/README.md) for details.

### Flux

Avigilon Flux is the cloud ingestion pipeline and ingress endpoint for sensor analytics metadata from ACC or Avigilon Unity.

See [docs](flux/README.md) for details.
