# Avigilon Flux

Avigilon Flux is the cloud ingestion pipeline and ingress endpoint for sensor analytics metadata from ACC or Avigilon Unity.

## Overview

```mermaid
flowchart LR
    classDef subgraphPadding fill:none,stroke:none;

    ACC["ACC / Avigilon Unity"]
    ACC --> EVHOL
    ACC --> EVHOC

    subgraph FLUX[Flux]
    subgraph PAD1[" "]
        subgraph EVHNS["Event Hub Namespace"]
            direction RL
            EVHOL["Event Hub Live Objects"]
            EVHOC["Event Hub Complete Objects"]
        end
    end
    end

    CSM["Consumers"]
    EVHOL --> CSM
    EVHOC --> CSM

    class PAD1 subgraphPadding;
```

**Live Objects**

Metadata for objects in the field of view, used for alarm workflows.

**Complete Objects**

Metadata for objects that have left the field of view, used for search workflows.

## Resources

- Event Hub Namespace
- Key Vault

## Security

- Producers/Consumers use AMQP over WebSockets (443)
- Producers use a service principal to acquire "send" permissions
- Consumers use a SAS token to acquire "listen" permissions on a consumer group basis
- BYOK encryption is enabled, key stored in Vault with auto-rotation enabled every 90 days
- Minimum TLS version is 1.2

## Environments

```mermaid
flowchart LR
    CI["Continous Integration (CI)"]
    QA["Quality Assurance (QA)"]
    PROD["Production"]
    CI --> QA --> PROD
```

## Regions

- East US

## Future

- Add service to process complete object metadata
- Add a storage account to write complete object metadata with appropriate encryption, retention, and permissions
