param (
    [Parameter()]
    [String]$TemplatePath
)
Get-childitem -Path ${env:INFRAFOLDER}/*.json  -Recurse| Test-AzTemplate  -Pester